This programm is created by Marco v/d Berg with the help from John Korejwa

This programm is capable of showing the contents of different archives
and some archives can be extracted.
Archives which contents can be shown are.
ZIP,GZ,TGZ,TAR,ARC,ARJ,RAR,CAB,LZH,LHA
Archives which contents can be extracted are.
ZIP,GZ,TGZ,TAR

All coding is done in vb without use of third party components so everybody
who needs to unzip something in there project can use this one so the need for
third party components will be absolete.
Don't expect it to be fast but it is as fast as we could get it.

it is far from Finished but since i haven't much time lately, i uploaded
it to PSC so maybe someone else could use the code from it.

Not all parts are coded by me but some parts are coded by john korejwa and others.
